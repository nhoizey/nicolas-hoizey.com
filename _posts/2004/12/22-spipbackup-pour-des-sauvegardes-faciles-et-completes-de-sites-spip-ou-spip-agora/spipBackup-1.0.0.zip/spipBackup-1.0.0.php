<?php
/*
* -------------------------------------------------------------------
* Configuration options
* -------------------------------------------------------------------
*/

// Directory where the files will be created
define('DIRECTORY', 'backup');
define('ARCHIVE_PREFIX', 'mon_site_spip');

// Database connection parameters
define('BASE_HOST', 'localhost');
define('BASE_NAME', 'spip');
define('BASE_USERNAME', 'root');
define('BASE_USERPASS', '');

// Number of archives to keep (0 for all)
define('ARCHIVES_NUMBER', 3);

// Use visualy improved version (requires PEAR::HTML_Progress)
define('VISUAL_FRIENDLY', false);

/*
* -------------------------------------------------------------------
* Script, don't modify!
* -------------------------------------------------------------------
*/
?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3c.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>SPIP backup tool</title>
<style type="text/css">
<!--
body {
	font-family: tahoma, georgia, verdana, sans-serif;
	font-size: 0.8em;
}
// -->
</style>
<?php
// PEAR Components
require_once 'DB.php';
require_once 'Archive/Tar.php';
if (VISUAL_FRIENDLY) {
    include_once 'HTML/Progress.php';
}

// Try to get some time
@set_time_limit(0);

if (isset($_GET['generate']) && ereg('(database|files|both)', $_GET['generate'])) {
    if (VISUAL_FRIENDLY) {
    	$bar1 = new HTML_Progress(HTML_PROGRESS_BAR_HORIZONTAL);
    	$bar1->setBorderPainted(true);
    	$bar1->setStringPainted(true);
    	
    	$ui1 =& $bar1->getUI();
    	$ui1->setFillWay('natural');
    	$ui1->setCellCount(50);
    	$ui1->setCellAttributes('active-color=#686a74 inactive-color=#ecebcf width=8');
    	$ui1->setBorderAttributes('width=1 color=#686a74');
    	$ui1->setStringAttributes('width=170 height=20 valign=top align=left');
    	
    	$bar2 = new HTML_Progress(HTML_PROGRESS_BAR_HORIZONTAL);
    	$bar2->setBorderPainted(true);
    	$bar2->setStringPainted(true);
    	
    	$ui2 =& $bar2->getUI();
    	$ui2->setFillWay('natural');
    	$ui2->setCellCount(50);
    	$ui2->setCellAttributes('active-color=#ce6642 inactive-color=#ffd595 width=8');
    	$ui2->setBorderAttributes('width=1 color=#ce6642');
    	$ui2->setStringAttributes('width=170 height=20 valign=top align=left');
    	?>
    	<style type="text/css">
    	<!--
    	<?php 
    	echo $bar1->getStyle();
    	echo $bar2->getStyle();
    	?>
    	// -->
    	</style>
    	<script type="text/javascript">
    	<!--
    	<?php
    	echo $bar1->getScript();
    	?>
    	//-->
    	</script>
        <?php
    }
    ?>
	</head>
	<body>
	<h1><a href="?">SPIP backup tool</a></h1>
    <?php
    if (VISUAL_FRIENDLY) {
        ?>
    	<h2>Generating new archive</h2>
    	<?php
    	echo $bar1->toHTML();
    	echo '<div>&nbsp;</div>';
    	echo $bar2->toHTML();
    	$bar1->display();
    	$bar2->display();
    }	
	$currentTime = time();
	$dirName = DIRECTORY.'/spip_dump_'.date('Ymd_His', $currentTime);
	if (!file_exists($dirName)) {
		mkdir($dirName);
		// Database
		if (ereg('(database|both)', $_GET['generate'])) {
			// Database connection
			$db =& DB::connect('mysql://'.BASE_USERNAME.':'.BASE_USERPASS.'@'.BASE_HOST.'/'.BASE_NAME);
			if (DB::isError($db)) {
			    die($db->getMessage());
			}
			$db->setFetchMode(DB_FETCHMODE_ASSOC);
            if (VISUAL_FRIENDLY) {
    			$bar1->setString('Saving database ...');
    			$bar1->display();
    			$bar2->setValue(0);
    		    $bar2->display();
            }
			mkdir($dirName.'/database');
			
			$tables = $db->getCol('SHOW TABLES');
			$i = 0;
			foreach ($tables as $table) {
				$i++;
                if (VISUAL_FRIENDLY) {
    				$bar2->setString(intval($i * 100 / count($tables)).'% - create dump for table '.$table);
    			    $bar2->display();
                }
				$file = fopen($dirName.'/database/'.BASE_HOST.'_'.BASE_NAME.'_'.$table.'.sql', 'w+');
				fputs($file, '# Host  : '.BASE_HOST);
				fputs($file, "\n".'# Base  : '.BASE_NAME);
				fputs($file, "\n".'# Table : '.$table);
				fputs($file, "\n".'# Date  : '.date('d/m/Y H:i', $currentTime));
				fputs($file, "\n\n".'# Structure');
				fputs($file, "\n\n".'DROP TABLE IF EXISTS '.$table.';');
				$createQuery = $db->getRow('SHOW CREATE TABLE '.$table);
				fputs($file, "\n".$createQuery['Create Table']);
				
				// Indexation data not archived
				if (!strpos($table, 'index')) {
					fputs($file, "\n\n".'# Data'."\n");
					$empty = $db->getOne('SELECT COUNT(*) FROM '.$table);
					if ($empty != 0) {
						$data = $db->query('SELECT * FROM '.$table);
						while ($row =& $data->fetchRow()) {
							$queryFields = 'INSERT INTO '.$table.' (';
							$queryValues = ') VALUES (';
							foreach ($row as $field => $value) {
								$queryFields .= $field.', ';
								$queryValues .= '\''.addslashes($value).'\', ';
							}
							fputs($file, "\n".substr($queryFields, 0, -2).substr($queryValues, 0, -2).');');
						}
					}
				}
				fclose($file);
                if (VISUAL_FRIENDLY) {
                    $bar2->setValue(intval($i * 100 / count($tables)));
                    $bar2->display();
                }
			}
			$db->disconnect();
		}
        if (VISUAL_FRIENDLY) {
    		$bar1->setValue(20);
    	    $bar1->display();
    		$bar2->setString('done');
    		$bar2->setValue(100);
    	    $bar2->display();
        }

		// Files
		if (ereg('(files|both)', $_GET['generate'])) {
            if (VISUAL_FRIENDLY) {
    			$bar1->setString('Saving files ...');
    		    $bar1->display();
            }
			$tarFiles = new Archive_Tar($dirName.'/files.tar');
			$tarFiles->create('./IMG/');
		}
        if (VISUAL_FRIENDLY) {
    		$bar1->setValue(40);
    	    $bar1->display();
        }

		// Create the final tar, gzipped if possible
        if (VISUAL_FRIENDLY) {
    		$bar1->setString('Creating archive ...');
    	    $bar1->display();
        }
		$archiveName = DIRECTORY.'/'.ARCHIVE_PREFIX.'_'.date('Ymd_His', $currentTime).'_'.$_GET['generate'];
		if (function_exists('gzopen')) {
			$tarFile = new Archive_Tar($archiveName.'.tar.gz', 'gz');
		} else {
			$tarFile = new Archive_Tar($archiveName.'.tar');
		}
		$tarFile->create($dirName);
        if (VISUAL_FRIENDLY) {
    		$bar1->setValue(60);
    	    $bar1->display();
    		$bar1->setString('Removing temporary files ...');
    	    $bar1->display();
        }
		removedir($dirName);
        if (VISUAL_FRIENDLY) {
    		$bar2->setString('done');
    		$bar2->setValue(100);
    	    $bar2->display();
    		$bar1->setValue(80);
    	    $bar1->display();
        }
	
		if (ARCHIVES_NUMBER > 0) {
            if (VISUAL_FRIENDLY) {
    			$bar1->setString('Removing old archives ...');
    	    	$bar1->display();
            }
			$files = array();
			$dir = opendir(DIRECTORY);
			while ($file = readdir($dir)) {
				if($file != '.' && $file != '..' && !is_dir(DIRECTORY.'/'.$file)) {
					$files[] = $file;
				}
			}
			closedir($dir);
			sort($files);
			if (count($files) > ARCHIVES_NUMBER) {
				for ($i = 0; $i < count($files) - ARCHIVES_NUMBER; $i++) {
					$file = $files[$i];
                    if (VISUAL_FRIENDLY) {
    					$bar2->setString('remove archive '.$file);
    				    $bar2->display();
                    }
					unlink(DIRECTORY.'/'.$file);
				}
			}
		}
        if (VISUAL_FRIENDLY) {
    		$bar1->setValue(100);
    	    $bar1->display();
        }
	}
} elseif (isset($_GET['remove']) && file_exists(DIRECTORY.'/'.$_GET['remove'])) {
    if (VISUAL_FRIENDLY) {
    	$bar2 = new HTML_Progress(HTML_PROGRESS_BAR_HORIZONTAL);
    	$bar2->setBorderPainted(true);
    	$bar2->setStringPainted(true);
    	
    	$ui2 =& $bar2->getUI();
    	$ui2->setFillWay('natural');
    	$ui2->setCellCount(50);
    	$ui2->setCellAttributes('active-color=#686a74 inactive-color=#ecebcf width=8');
    	$ui2->setBorderAttributes('width=1 color=#686a74');
    	$ui2->setStringAttributes('width=170 height=20 valign=top align=left');
    	?>
    	<style type="text/css">
    	<!--
    	<?php 
    	echo $bar2->getStyle();
    	?>
    	// -->
    	</style>
    	<script type="text/javascript">
    	<!--
    	<?php
    	echo $bar2->getScript();
    	?>
    	//-->
    	</script>
        <?php
    }
    ?>
	</head>
	<body>
	<h1><a href="?">SPIP backup tool</a></h1>
	<?php
	if (is_dir(DIRECTORY.'/'.$_GET['remove'])) {
        if (VISUAL_FRIENDLY) {
    		echo '<h2>Removing old directory</h2>';
    		echo $bar2->toHTML();
    		$bar2->display();
        }
		removeDir(DIRECTORY.'/'.$_GET['remove']);
        if (VISUAL_FRIENDLY) {
    		$bar2->setString('done');
    		$bar2->setValue(100);
    	    $bar2->display();
        }
	} else {
        if (VISUAL_FRIENDLY) {
            echo '<h2>Removing old archive</h2>';
    		echo $bar2->toHTML();
    		$bar2->display();
        }
		unlink(DIRECTORY.'/'.$_GET['remove']);
        if (VISUAL_FRIENDLY) {
    		$bar2->setString('done');
    		$bar2->setValue(100);
    	    $bar2->display();
        }
	}
} else {
	?>
	</head>
	<body>
	<h1><a href="?">SPIP backup tool</a></h1>
	<?php
}
echo '<h2>Directories</h2>';
echo '<ul>';
$i = 0;
$dir = opendir(DIRECTORY);
while ($item = readdir($dir)) {
	if(is_dir(DIRECTORY.'/'.$item) && $item != '.' && $item != '..') {
		$i++;
		echo '<li>[<a href="?remove='.$item.'">remove</a>] '.$item.'</li>';
	}
}
if ($i == 0) {
	echo '<li>none</li>';
}
closedir($dir);
echo '</ul>';

echo '<h2>Archives ('.ARCHIVES_NUMBER.' maximum)</h2>';
echo '<ul>';
$i = 0;
$dir = opendir(DIRECTORY);
while ($item = readdir($dir)) {
	if(is_file(DIRECTORY.'/'.$item)) {
		$i++;
		echo '<li>[<a href="'.DIRECTORY.'/'.$item.'">download</a> | <a href="?remove='.$item.'">remove</a>] '.$item.' ('.niceFileSize(DIRECTORY.'/'.$item).')</li>';
	}
}
if ($i == 0) {
	echo '<li>none</li>';
}
closedir($dir);
echo '</ul>';
?>
<h2>New archive</h2>
<p>Generate new archive with</p>
<ul>
	<li>only the <a href="?generate=database">database</a></li>
	<li>only the <a href="?generate=files">files</a></li>
	<li><a href="?generate=both">both</a> the database and the files</li>
</ul>
<?php
/*
* Functions
*/

function removeDir($dirName)
{
	global $bar2;
	if (is_dir($dirName)) {
		$dir = opendir($dirName);
		while ($item = readdir($dir)) {
			if($item != '.' && $item != '..') {
				if(is_dir($dirName.'/'.$item)) {
					removeDir($dirName.'/'.$item);
				} else {
                    if (VISUAL_FRIENDLY) {
    					$bar2->setString('remove file '.$dirName.'/'.$item);
    					$bar2->setValue(($bar2->getValue() + 10) % 100);
    				    $bar2->display();
                    }
					unlink($dirName.'/'.$item);
				}
			}
		}
		closedir($dir);
        if (VISUAL_FRIENDLY) {
    		$bar2->setString('remove directory '.$dirName);
    	    $bar2->display();
        }
		rmdir($dirName);
	}
}

function copyDirContent($dirFrom, $dirTo)
{
	global $bar2;
	if (is_dir($dirFrom) && is_dir($dirTo)) {
		$dir = opendir($dirFrom);
		while ($item = readdir($dir)) {
			if($item != '.' && $item != '..') {
				if(is_dir($dirFrom.'/'.$item)) {
                    if (VISUAL_FRIENDLY) {
    					$bar2->setString('create directory '.$dirTo.'/'.$item);
    					$bar2->setValue(($bar2->getValue() + 10) % 100);
    				    $bar2->display();
                    }
					mkdir($dirTo.'/'.$item);
					copyDirContent($dirFrom.'/'.$item, $dirTo.'/'.$item);
				} else {
                    if (VISUAL_FRIENDLY) {
    					$bar2->setString('copy '.$dirFrom.'/'.$item.'<br />to '.$dirTo);
    					$bar2->setValue(($bar2->getValue() + 10) % 100);
    				    $bar2->display();
                    }
					copy($dirFrom.'/'.$item, $dirTo.'/'.$item);
				}
			}
		}
		closedir($dir);
	}
}

function niceFileSize($file) {
	$size = filesize($file);
	$sizes = array('octets', 'ko', 'Mo', 'Go', 'To', 'Po', 'Eo');
	$ext = $sizes[0];
	for ($i = 1; (($i < count($sizes)) && ($size >= 1024)); $i++) {
		$size = $size / 1024;
		$ext  = $sizes[$i];
	}
	return round($size, 2).' '.$ext;
}
?>
</body>
</html>